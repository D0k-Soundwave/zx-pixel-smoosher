# ZX Pixel Smoosher v1.1.3

**Release Date:** 2025-09-06 09:59:43 UTC
**Release Type:** patch

## Changes since v1.1.2

### 🚀 New Features
_No new features in this release_

### 🐛 Bug Fixes
- fix: restore working flood fill functionality (D0k)

### 📚 Documentation
_No documentation changes in this release_

### 🔧 Maintenance
_No maintenance changes in this release_

### 🎨 ZX Spectrum Features
_No ZX Spectrum specific changes in this release_

### ⚡ Performance Improvements
_No performance improvements in this release_

### 📊 Technical Details
- **Commit Range:** v1.1.2..HEAD
- **Total Commits:** 1
- **Contributors:** 1
- **Files Changed:** 1
- **Lines Added:** 1
- **Lines Deleted:** 1

---

**Full Changelog:** https://github.com/D0k-Soundwave/zx-pixel-smoosher/compare/v1.1.2...v1.1.3
