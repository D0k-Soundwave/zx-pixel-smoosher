# ZX Pixel Smoosher v1.1.2

**Release Date:** 2025-09-05 16:48:06 UTC
**Release Type:** patch

## Changes since v1.1.1

### 🚀 New Features
_No new features in this release_

### 🐛 Bug Fixes
- fix: remove npm cache from all workflows for pure JS project (D0k)

### 📚 Documentation
_No documentation changes in this release_

### 🔧 Maintenance
_No maintenance changes in this release_

### 🎨 ZX Spectrum Features
_No ZX Spectrum specific changes in this release_

### ⚡ Performance Improvements
- fix: remove npm cache from all workflows for pure JS project (D0k)

### 📊 Technical Details
- **Commit Range:** v1.1.1..HEAD
- **Total Commits:** 1
- **Contributors:** 1
- **Files Changed:** 6
- **Lines Added:** 0
- **Lines Deleted:** 131

---

**Full Changelog:** https://github.com/D0k-Soundwave/zx-pixel-smoosher/compare/v1.1.1...v1.1.2
