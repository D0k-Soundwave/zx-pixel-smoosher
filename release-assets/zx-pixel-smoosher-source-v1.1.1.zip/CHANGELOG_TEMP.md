# ZX Pixel Smoosher v1.1.1

**Release Date:** 2025-09-05 16:45:08 UTC
**Release Type:** patch

## Changes since v1.1.0

### 🚀 New Features
_No new features in this release_

### 🐛 Bug Fixes
- fix: add simplified GitHub Pages deployment workflow (D0k)

### 📚 Documentation
- docs: trigger GitHub Pages deployment (D0k)

### 🔧 Maintenance
_No maintenance changes in this release_

### 🎨 ZX Spectrum Features
- trigger: Deploy ZX Pixel Smoosher to GitHub Pages (D0k)

### ⚡ Performance Improvements
_No performance improvements in this release_

### 📊 Technical Details
- **Commit Range:** v1.1.0..HEAD
- **Total Commits:** 5
- **Contributors:** 1
- **Files Changed:** 3
- **Lines Added:** 41
- **Lines Deleted:** 0

---

**Full Changelog:** https://github.com/D0k-Soundwave/zx-pixel-smoosher/compare/v1.1.0...v1.1.1
